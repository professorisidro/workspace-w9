package br.com.meli.calculadoradecalorias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculadoradecaloriasApplicationTests {

	@Test
	void contextLoads() {
	}

}
