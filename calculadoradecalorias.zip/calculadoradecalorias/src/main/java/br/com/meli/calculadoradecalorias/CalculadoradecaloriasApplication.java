package br.com.meli.calculadoradecalorias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalculadoradecaloriasApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalculadoradecaloriasApplication.class, args);
	}

}
