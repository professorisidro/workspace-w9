package br.com.meli.multiservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultiservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MultiservicesApplication.class, args);
	}

}
