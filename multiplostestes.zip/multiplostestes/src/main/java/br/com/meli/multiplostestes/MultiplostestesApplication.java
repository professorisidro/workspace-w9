package br.com.meli.multiplostestes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultiplostestesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MultiplostestesApplication.class, args);
	}

}
