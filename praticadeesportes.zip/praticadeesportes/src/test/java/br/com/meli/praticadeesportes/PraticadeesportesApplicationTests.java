package br.com.meli.praticadeesportes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PraticadeesportesApplicationTests {

	@Test
	void contextLoads() {
	}

}
