package br.com.meli.praticadeesportes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PraticadeesportesApplication {

	public static void main(String[] args) {
		SpringApplication.run(PraticadeesportesApplication.class, args);
	}

}
