package br.com.meli.morse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MorseApplicationTests {

	@Test
	void contextLoads() {
	}

}
