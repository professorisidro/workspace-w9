package br.com.meli.objects;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ObjectsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ObjectsApplication.class, args);
	}

}
