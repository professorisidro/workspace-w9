package br.com.meli.h2test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class H2testApplicationTests {

	@Test
	void contextLoads() {
	}

}
